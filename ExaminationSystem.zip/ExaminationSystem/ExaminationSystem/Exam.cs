﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    // Abstract calss that cannot be instantiated, inherits from interfaces (IComparable & Iclonable)
    internal abstract class Exam : IComparable, ICloneable
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int NumberOfQuestions { get; set; }
        // Exam mode as given (Strated, Queued, Finished)
        public string Mode { get; set; }
        // Property for the subject of the exam.
        public Subject subject {  get; set; }
        // Dictoinary <Key, Value> <Question, Answer>.
        public Dictionary<Question, Answer> QuestionAnswer { get; set; }

        // Constructor to initialize our properties
        public Exam (DateTime _StartTime, DateTime _EndTime, int _NumberOfQuestions, Subject _subject)
        {
            StartTime = _StartTime;
            EndTime = _EndTime;
            NumberOfQuestions = _NumberOfQuestions;
            Mode = "Queued";
            subject = _subject;
            QuestionAnswer = new Dictionary<Question, Answer> ();
        }
        // Abstract method that will be implemented by Sub Class
        public abstract void ShowingTheExam();

        // Implementation of CompareTo() method of Icomparable
        public int CompareTo(object obj)
        {
            if (obj == null)
                return 1;
            Exam exam = obj as Exam;

            if (exam != null)
            { 
                return this.StartTime.CompareTo(exam.StartTime);
            }
            else
                return 0;
        }
        // Implementation of Clone() method of Iclonable
        public object Clone()
        {
            return this.MemberwiseClone();
        }

        // Override ToString() to display the exam object.
        public override string ToString()
        {
            return $"Exam: StartTime: {StartTime}, EndTime: {EndTime}";
        }
        // Implementing GetHashCode() method
        public override int GetHashCode()
        {
            return HashCode.Combine(StartTime,EndTime);
        }
        // Implementing Equals() method
        public override bool Equals(object? obj)
        {
            return obj is Exam exam && StartTime == exam.StartTime && EndTime == exam.EndTime;
        }
    }
}