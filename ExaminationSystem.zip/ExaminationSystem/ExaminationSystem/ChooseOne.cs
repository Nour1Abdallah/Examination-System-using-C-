﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class ChooseOne : Question
    {
        // string property for the quetion choices
        public string[] Choices {  get; set; }

        // Property for the answer
        public string Answer { get; set; }

        // constructor for this class that inherits from the base cto of the super class
        public ChooseOne (string body, int marks, string header, string[] _Choices, string _Answer )
            : base(body, marks, header, "Choose one correct answer from the next choices")
        {
            Choices = _Choices;
            Answer = _Answer;
        }
        // Implementing the abstract method:
        public override void ShowQuestion()
        {
            Console.WriteLine($"{Header}\n{Body} (Choose one answer from the next choices):");

            // To loop through the choices and display them
            foreach (var item in Choices)
            {
                Console.WriteLine(item);
            }
        }
    }
}
