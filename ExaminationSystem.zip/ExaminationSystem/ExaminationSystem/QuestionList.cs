﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ExaminationSystem
{
    internal class QuestionList : List<Question> //File
    {
        // Field to where questions will be written in the file.
        string fileName;

        public QuestionList(string _fileName)
        {
            fileName = _fileName;
        }
        public virtual void Add(Question Q)
        {
            base.Add(Q);
            InsertTheQuestionToFile(Q);
        }

        private void InsertTheQuestionToFile(Question Q)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(fileName, true))
                {
                    writer.WriteLine($"Header: {Q.Header}");
                    writer.WriteLine($"Question: {Q.Body}");
                    writer.WriteLine($"Marks: {Q.Marks}");
                    writer.WriteLine($"Type: {Q.QuestionType}");
                    
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Error logging question to file: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Please contact with the admin of the control");
            }
        }
    }
}