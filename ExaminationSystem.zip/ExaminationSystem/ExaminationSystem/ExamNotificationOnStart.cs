﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class ExamNotificationOnStart
    {
        // Declare an event using EventHandler with ExamEventArgs
        public event EventHandler<ExamEvent> ExamStarted; // puplisher صاحب الإيفينت

        // Method to trigger the ExamStarted event
        public void StartExam()
        {
            OnExamStarted(new ExamEvent ("The exam has started. Please prepare your self!"));
        }

        // Protected method to raise the event
        protected virtual void OnExamStarted(ExamEvent Ex)
        {
            ExamStarted?.Invoke(this, Ex); // FireTheEvent 
        }
    }
}
