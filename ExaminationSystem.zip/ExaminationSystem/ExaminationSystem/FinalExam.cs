﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class FinalExam : Exam
    {
        public FinalExam (DateTime StartTime, DateTime EndTime, int NumberOfQuestions, Subject subject)
            : base (StartTime, EndTime, NumberOfQuestions, subject)
        {
        }
        public override void ShowingTheExam()
        {
            Console.WriteLine("Final Exam shows only the questions");
            foreach (var question in QuestionAnswer.Keys)
            {
                question.ShowQuestion();
            }
        }
    }
}
