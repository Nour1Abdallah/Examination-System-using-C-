﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class PracticalExam : Exam
    {
        // Constructor to initialize the PracticalExam with base class
        public PracticalExam(DateTime StartTime, DateTime EndTime, int numberOfQuestions, Subject subject)
        : base(StartTime, EndTime, numberOfQuestions, subject)
        {
        }
        // Overriding metheod to display the questions and answers for it.
        public override void ShowingTheExam()
        {
            Console.WriteLine("The practical exam shows the question and the answer...");
            // Looping through each question in the dictionary using foreach
            foreach (var question in QuestionAnswer.Keys)
            {
                question.ShowQuestion();
                Console.WriteLine($"The correct answer is: {QuestionAnswer[question].StdAnswer}");
            }
        }
    }
}
