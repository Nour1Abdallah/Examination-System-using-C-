﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class Student
    {
        public string Name { get; set; } // The name of the student

        // Constructor to initialize the student's name
        public Student(string _Name)
        {
            Name = _Name;
        }

        // Method to handle notifications when the exam starts
        public void Notify(object sender, ExamEvent Ex)
        {
            Console.WriteLine($"{Name} notified: {Ex.Message}");
        }
    }
}
