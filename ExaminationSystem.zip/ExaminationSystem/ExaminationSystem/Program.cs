﻿namespace ExaminationSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Create a Subject object
            var mathSubject = new Subject("Mathematics"); // Example subject

            //Create instances of PracticalExam and FinalExam
            var practicalExam = new PracticalExam(DateTime.Now, DateTime.Now.AddHours(2), 5, mathSubject);
            var finalExam = new FinalExam(DateTime.Now, DateTime.Now.AddHours(3), 10, mathSubject);

            //Add questions to the exams
            var question1 = new TrueOrFalseQuestion("Is 2+2=4?", 1, "Basic Math", "True");
            var question2 = new ChooseOne("What is the capital of France?", 2, "Geography",
                            new string[] { "Paris", "London", "Berlin" }, "Paris");

            // Adding the questions to practicalExam
            practicalExam.QuestionAnswer.Add(question1, new Answer("True", true));
            practicalExam.QuestionAnswer.Add(question2, new Answer("Paris", true));

            // Adding the questions to finalExam
            finalExam.QuestionAnswer.Add(question1, new Answer("True", true));
            finalExam.QuestionAnswer.Add(question2, new Answer("Paris", true));

            // Allow the user to select the type of exam
            Console.WriteLine("Choose Exam Type:\n1. Practical Exam\n2. Final Exam");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                practicalExam.ShowingTheExam(); // Show Practical Exam
            }
            else if (choice == 2)
            {
                finalExam.ShowingTheExam(); // Show Final Exam
            }
            else
            {
                Console.WriteLine("Invalid choice!");
            }

            // Set up event notifications
            var examNotifier = new ExamNotificationOnStart(); // Create an ExamNotification object

            // Create students and subscribe them to the notification
            var student1 = new Student("folan");
            var student2 = new Student("ellan");
            var student3 = new Student("zaid");
            var student4 = new Student("ebied");

            examNotifier.ExamStarted += student1.Notify; 
            examNotifier.ExamStarted += student2.Notify; 

            // Trigger the "Starting" mode for the exam
            Console.WriteLine("\nStarting the exam...");
            practicalExam.Mode = "Starting"; // Change exam mode
            examNotifier.StartExam(); // Notify all students that the exam is starting

            Console.WriteLine("Exam is now in progress...");
        }
    }
}