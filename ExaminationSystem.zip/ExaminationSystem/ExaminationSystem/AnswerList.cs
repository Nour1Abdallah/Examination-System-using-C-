﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class AnswerList : List<Answer>
    {
        // To get the correct answer
        public List<Answer> GetCorrectAnswers()
        {
            return this.Where(answer => answer.IstheAnswerIsCorrect).ToList();

        }

        // Display all correct answers
        public void DisplayCorrectAnswers()
        {
            Console.WriteLine("Correct Answers:");
            foreach (var answer in GetCorrectAnswers())
            {
                Console.WriteLine(answer.StdAnswer);
            }
        }

        // Add a new answer, ensuring no duplicates
        public void AddAnswer(string answerText, bool isCorrect)
        {
            if (this.Any(answer => answer.StdAnswer.Equals(answerText, StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine("Answer already exists in the list.");
                return;
            }
            this.Add(new Answer(answerText, isCorrect));
        }
    }
}
