﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class TrueOrFalseQuestion : Question
    {
        // property for answer the question
        public string AnswerForTheQuestion { get; set; }

        //constructor that inherits from the base calss ctor (Question)
        public TrueOrFalseQuestion(string body, int marks, string header, string _AnswerForTheQuestion) 
            : base (body, marks, header, "True Or False")
        {
            AnswerForTheQuestion = _AnswerForTheQuestion;   
        }
        // Override the method
        public override void ShowQuestion()
        {
            Console.WriteLine($"{Header}\n{Body} (True/False): {AnswerForTheQuestion}");
        }
    }
}
