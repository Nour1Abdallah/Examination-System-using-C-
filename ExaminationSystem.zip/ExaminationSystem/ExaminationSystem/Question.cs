﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    // Abstract class that con not be instatiated
    internal abstract class Question
    {
        // Properties for providing encapsulation to access each atrribute.
        public string Body { get; set; }
        public int Marks { get; set; }
        public string Header { get; set; }
        public string QuestionType { get; set; }

        // Constructor
        public Question(string _Body, int _Marks, string _Header, string _QuestionType)
        {
            Body = _Body;
            Marks = _Marks;
            Header = _Header;
            QuestionType = _QuestionType;
        }
        // Abstract method which will not be implemented here, but in the derived classes (TrueOrFalse, ChooseOne & ChooseAll)
        public abstract void ShowQuestion();
        
        public override string ToString()
        {
            return $"Header: {Header}, Body: {Body}, Marks: {Marks}";
        }
    }
}
