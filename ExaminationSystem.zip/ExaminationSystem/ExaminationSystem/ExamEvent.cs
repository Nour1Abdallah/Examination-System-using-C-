﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class ExamEvent : EventArgs
    {
        public string Message { get; set; } // Notification message

        // Constructor to initialize the message
        public ExamEvent(string _Message)
        {
            Message = _Message;
        }
    }
}
