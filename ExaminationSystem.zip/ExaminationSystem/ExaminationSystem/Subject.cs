﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class Subject
    {
        public string SubjectName {  get; set; }
        public Subject(string _SubjectName)
        {
            SubjectName = _SubjectName;
        }
    }
}
