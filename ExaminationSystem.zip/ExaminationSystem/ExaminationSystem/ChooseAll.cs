﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem
{
    internal class ChooseAll : Question
    {
        // string property for the quetion choices
        public string[] Choices { get; set; }
        // Property for the answer
        public string Answers { get; set; }

        // constructor for this class that inherits from the base cto of the super class
        public ChooseAll(string body, int marks, string header, string[] _Choices, string _Answers)
            : base (body, marks, header, "Choose all choices")
        {
            Choices = _Choices;
            Answers = _Answers;
        }
        // Implementing the abstract method:
        public override void ShowQuestion()
        {
            Console.WriteLine($"{Header}\n{Body} (Choose all answers from the next choices ):");

            // To loop through the choices and display them
            foreach (var item in Choices)
            {
                Console.WriteLine(item);
            }
        }
    }
}
